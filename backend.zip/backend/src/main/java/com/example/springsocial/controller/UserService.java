package com.example.springsocial.controller;

public class UserService {

}
