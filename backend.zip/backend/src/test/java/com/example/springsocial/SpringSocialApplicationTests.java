package com.example.springsocial;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class SpringSocialApplicationTests {

	@Test
	public void contextLoads() {
	}

}
